# Build

To build the examples, run
```bash
$ make -j
```

# Run

To execute the main program run
```bash
$ make run
```

To run each individual `producer-consumer` examples run
```bash
$ make run-prod1
$ make run-prod2
$ make run-prod3
$ make run-prod4
$ make run-prod5
```
